﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_Das7
{
    public partial class Form1 : Form
    {
        interface IFlat
        {
            int Number { get; set; }
            int Area { get; set; }
            int Floor { get; set; }
            bool HasBalcony { get; set; }
            double EstimatedPrice { get; }

            string GetAdress();
            void SetAdress(string adress);
            void UpdateFloor(int newFloor);
            void UpdateArea(ref int newArea);
        }

        [Serializable]
        public class Flat : IFlat, IComparable<Flat>
        {
            private int number;
            private int area;
            private string adress;

            public int Number { get => number; set => number = value; }
            public int Area { get => area; set => area = value; }
            public int Floor { get; set; }
            public bool HasBalcony { get; set; }

            public double EstimatedPrice => area * 1000;

            public Flat() { }

            public Flat(int number, int area, string adress, int floor, bool hasBalcony)
            {
                Number = number;
                Area = area;
                this.adress = adress;
                Floor = floor;
                HasBalcony = hasBalcony;
            }

            public string GetAdress() => adress;
            public void SetAdress(string adress) => this.adress = adress;
            public void UpdateFloor(int newFloor) => Floor = newFloor;
            public void UpdateArea(ref int newArea) => Area = newArea;

            public int CompareTo(Flat other)
            {
                if (other == null) return 1;
                return this.Area.CompareTo(other.Area);
            }

            public override string ToString()
            {
                return $"Номер: {Number}, Площа: {Area}, Поверх: {Floor}, Балкон: {(HasBalcony ? "Так" : "Ні")}, Адреса: {adress}, Ціна: {EstimatedPrice} грн";
            }
        }


        Flat fFlat = null;
        List<Flat> flatList = new List<Flat>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            fFlat = new Flat(
               Convert.ToInt32(tbNumber.Text),
               Convert.ToInt32(tbArea.Text),
               tbAdress.Text,
               Convert.ToInt32(tbFloor.Text),
               cbBalcony.Checked
           );
            MessageBox.Show("Квартиру збережено!");
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            if (fFlat != null)
            {
                MessageBox.Show(
                    "Номер квартири: " + fFlat.Number + "\n" +
                    "Площа: " + fFlat.Area + "\n" +
                    "Поверх: " + fFlat.Floor + "\n" +
                    "Балкон: " + (fFlat.HasBalcony ? "Так" : "Ні") + "\n" +
                    "Адреса: " + fFlat.GetAdress() + "\n" +
                    "Оцінка вартості: " + fFlat.EstimatedPrice + " грн",
                    "Інформація про квартиру");
            }
            else
            {
                MessageBox.Show("Квартира не збережена!");
            }
        }

        private void btnCreateList_Click(object sender, EventArgs e)
        {
            flatList.Clear();
            flatList.Add(new Flat(1, 55, "Вул. Озерна 1", 2, true));
            flatList.Add(new Flat(2, 42, "Вул. Озерна 2", 1, false));
            flatList.Add(new Flat(3, 60, "Вул. Озерна 3", 5, true));
            flatList.Add(new Flat(4, 38, "Вул. Озерна 4", 3, false));
            flatList.Insert(2, new Flat(5, 50, "Вул. Озерна 5", 4, true));
            flatList.Add(new Flat(6, 65, "Вул. Озерна 6", 6, true));

            MessageBox.Show("Список квартир створено та заповнено!");
        }

        private void btnShowFor_Click(object sender, EventArgs e)
        {
            string result = "";
            for (int i = 0; i < flatList.Count; i++)
            {
                Flat f = flatList[i];
                result += $"[{i}] №{f.Number}, {f.Area}м², Поверх {f.Floor}, Балкон: {(f.HasBalcony ? "Так" : "Ні")}, " +
                    $"Адреса: {f.GetAdress()}, Ціна: {f.EstimatedPrice} грн\n";
            }
            MessageBox.Show(result, "Список квартир (for)");
        }

        private void btnShowListForeach_Click(object sender, EventArgs e)
        {
            string result = "";
            foreach (Flat f in flatList)
            {
                result += $"№{f.Number}, {f.Area}м², Поверх {f.Floor}, Балкон: {(f.HasBalcony ? "Так" : "Ні")}, " +
                    $"Адреса: {f.GetAdress()}, Ціна: {f.EstimatedPrice} грн\n";
            }
            MessageBox.Show(result, "Список квартир (foreach)");
        }

        private void btnSaveToTextFile_Click(object sender, EventArgs e)
        {
            Flat flat = new Flat(7, 77, "Вул. Шевченка 7", 3, true);
            string path = "flat_info.txt";
            File.WriteAllText(path, flat.ToString());
            MessageBox.Show($"Текстовий файл створено:\n{Path.GetFullPath(path)}");
        }

        private void btnSerializeBinary_Click(object sender, EventArgs e)
        {
            Flat flat = new Flat(8, 88, "Вул. Шевченка 8", 4, false);
            string path = "flat_data.bin";

            using (FileStream fs = new FileStream(path, FileMode.Create))
            {
#pragma warning disable SYSLIB0011
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, flat);
#pragma warning restore SYSLIB0011
            }

            MessageBox.Show($"Бінарний файл створено:\n{Path.GetFullPath(path)}");
        }
    }
}
